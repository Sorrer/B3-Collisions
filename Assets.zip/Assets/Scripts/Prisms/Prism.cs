﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Prism : MonoBehaviour
{
    public int pointCount = 3;
    public Vector3[] points;
    public float midY, height;

    public GameObject prismObject;
}
